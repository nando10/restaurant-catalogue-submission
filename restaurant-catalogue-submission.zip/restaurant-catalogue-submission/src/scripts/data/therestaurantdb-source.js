import API_ENDPOINT from '../globals/api-endpoint';

class TheRestaurantDbSource {
  static async homeRestaurants() {
    const response = await fetch(API_ENDPOINT.HOME_RESTAURANT);
    const responseJson = await response.json();
    return responseJson.restaurants;
  }

  static async likeRestaurants() {
    const response = await fetch(API_ENDPOINT.LIKE_RESTAURANT);
    const responseJson = await response.json();
    return responseJson.restaurant;
  }

  static async detailRestaurants(id) {
    const response = await fetch(API_ENDPOINT.DETAIL_RESTAURANT(id));
    const responseJson = await response.json();
    return responseJson.restaurant;
  }
}

export default TheRestaurantDbSource;
