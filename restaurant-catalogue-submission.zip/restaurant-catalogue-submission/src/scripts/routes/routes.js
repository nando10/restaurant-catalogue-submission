import HomeRestaurant from '../views/pages/home-restaurant';
import DetailRestaurant from '../views/pages/detail-restaurant';
import LikeRestaurant from '../views/pages/like-restaurant';

const routes = {
  '/': HomeRestaurant, // default page
  '/home-restaurant': HomeRestaurant,
  '/detail-restaurant/:id': DetailRestaurant,
  '/like-restaurant': LikeRestaurant,
};

export default routes;
